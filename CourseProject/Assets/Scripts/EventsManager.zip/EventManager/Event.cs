namespace SDD.Events {

  /// <summary>
  /// Base event for all EventManager events.
  /// </summary>
  public class Event {
  }
}
